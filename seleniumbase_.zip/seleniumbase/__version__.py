# seleniumbase package
__version__ = "4.21.1"
